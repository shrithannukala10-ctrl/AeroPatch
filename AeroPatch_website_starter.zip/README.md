# AeroPatch — Pothole reporting website

A responsive React + Firebase website where signed-in users can report potholes, pin locations on a map, optionally upload a photo, and track the status of their own reports.

## Features
- Email/password sign-up and sign-in (required)
- Click map to place a pin or use browser GPS with permission
- Pothole title, description, severity, and optional photo
- Firestore report records and Firebase Storage photo uploads
- Personal report list and status filter
- Responsive layout
- Firestore and Storage security rules included

## 1. Install prerequisites
Install Node.js LTS from https://nodejs.org/ and a code editor such as VS Code.

## 2. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project named `aeropatch` (or another available ID).
2. In Project settings, add a Web app and copy its Firebase config values.
3. In **Authentication → Sign-in method**, enable **Email/Password**.
4. In **Firestore Database**, create a database. Start in production mode.
5. In **Storage**, get started and create the default bucket.
6. Paste the provided rules from `firestore.rules` into Firestore → Rules and publish.
7. Paste `storage.rules` into Storage → Rules and publish.
8. Add your local development domain (usually `localhost`) in Authentication → Settings → Authorized domains if it is not already listed.

## 3. Configure environment
1. Copy `.env.example` to a new file named `.env` in the project root.
2. Replace each placeholder with the corresponding Firebase Web App config value.
3. Do not commit `.env` to a public repository. Firebase web config is not a server secret, but security depends on correctly configured rules.

Example:
```
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project
VITE_FIREBASE_STORAGE_BUCKET=your-project.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
```

## 4. Run locally
Open a terminal in this folder and run:
```
npm install
npm run dev
```
Open the local URL Vite prints (normally `http://localhost:5173`). Create a test account and submit a test report.

To check production compilation:
```
npm run build
npm run preview
```

## 5. Deploy
### Firebase Hosting
1. Install Firebase CLI: `npm install -g firebase-tools`
2. Run `firebase login`
3. Run `firebase init hosting` in this folder.
4. Choose your Firebase project, set the public directory to `dist`, configure it as a single-page app, and do not overwrite `index.html`.
5. Build and deploy:
```
npm run build
firebase deploy --only hosting
```
After deployment, add the deployed domain under Firebase Authentication → Settings → Authorized domains if needed.

## Important limitations and safety
- This starter lets each user read only their own reports. It does not yet provide a public map of all community reports.
- Status changes are intentionally disabled in client security rules. For a real admin dashboard, implement a trusted backend or Firebase custom-claims admin role. Never allow ordinary users to set their own report to `resolved`.
- Public OpenStreetMap tile servers have usage policies and no uptime guarantee. For a high-traffic or commercial launch, choose a suitable tile provider and follow its terms. Keep visible map attribution.
- Browser GPS requires user permission and works on HTTPS or localhost. A map click works as an alternative.
- Test with fake reports first. Do not publish personal data or photos showing faces/number plates without permission.
- This is a project starter, not a formally audited production service. Before public launch, review privacy, abuse prevention, backups, and costs.

## Suggested next milestone
Build a verified reviewer/admin dashboard that can update statuses, flag duplicates, and later export verified coordinates for the AeroPatch repair robot. Do not automatically dispatch a robot based only on an unverified public report.
