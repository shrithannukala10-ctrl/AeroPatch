import { useEffect, useMemo, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged,
  signInWithEmailAndPassword, signOut, updateProfile
} from "firebase/auth";
import {
  addDoc, collection, onSnapshot, orderBy, query, serverTimestamp, where
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { MapContainer, Marker, TileLayer, useMapEvents } from "react-leaflet";
import L from "leaflet";
import { auth, db, storage } from "./firebase.js";

const markerIcon = new L.Icon({
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});

const initialCenter = [17.4435, 78.3772]; // Hyderabad default; users can move the pin anywhere.
const statusLabels = {
  submitted: "Reported",
  reviewing: "Under review",
  repairing: "Repair in progress",
  resolved: "Resolved"
};

function MapClick({ onPick }) {
  useMapEvents({ click(event) { onPick({ lat: event.latlng.lat, lng: event.latlng.lng }); } });
  return null;
}

function LocationMap({ position, onPick }) {
  return <div className="map-wrap">
    <MapContainer center={position ? [position.lat, position.lng] : initialCenter} zoom={13} scrollWheelZoom className="map">
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors'
        url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        maxZoom={19}
      />
      <MapClick onPick={onPick} />
      {position && <Marker position={[position.lat, position.lng]} icon={markerIcon} />}
    </MapContainer>
  </div>;
}

function AuthPanel() {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event) {
    event.preventDefault(); setError(""); setBusy(true);
    try {
      if (mode === "signup") {
        const result = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (name.trim()) await updateProfile(result.user, { displayName: name.trim() });
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (e) {
      setError(e.code === "auth/email-already-in-use" ? "That email already has an account."
        : e.code === "auth/invalid-credential" ? "Email or password is incorrect."
        : e.code === "auth/weak-password" ? "Use a password with at least 6 characters."
        : e.message || "Could not sign in. Please try again.");
    } finally { setBusy(false); }
  }

  return <main className="auth-shell">
    <div className="auth-art">
      <div className="brand brand-light"><span className="brand-mark">A</span><span>AeroPatch</span></div>
      <div className="auth-copy">
        <span className="eyebrow">COMMUNITY ROAD CARE</span>
        <h1>Better roads<br/>start with a pin.</h1>
        <p>Report potholes, share their exact location, and follow the progress of each report.</p>
        <div className="art-road"><div className="road-line"></div><span className="pin pin-one">●</span><span className="pin pin-two">●</span></div>
      </div>
      <small>Community reports help highlight issues. They do not automatically dispatch repair equipment.</small>
    </div>
    <div className="auth-form-side">
      <form className="auth-card" onSubmit={submit}>
        <span className="eyebrow">{mode === "login" ? "WELCOME BACK" : "JOIN AEROPATCH"}</span>
        <h2>{mode === "login" ? "Sign in to your account" : "Create your account"}</h2>
        <p className="muted">Sign in is required to submit and track reports.</p>
        {mode === "signup" && <label>Display name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" maxLength={60} required /></label>}
        <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" minLength={6} autoComplete={mode==="login"?"current-password":"new-password"} required /></label>
        {error && <div className="error">{error}</div>}
        <button className="primary full" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
        <p className="switch-auth">{mode === "login" ? "New to AeroPatch?" : "Already have an account?"} <button type="button" className="text-button" onClick={()=>{setMode(mode==="login"?"signup":"login");setError("");}}>{mode==="login"?"Create an account":"Sign in"}</button></p>
      </form>
    </div>
  </main>;
}

function App() {
  const [user, setUser] = useState(undefined);
  const [view, setView] = useState("report");
  const [reports, setReports] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState("moderate");
  const [position, setPosition] = useState(null);
  const [photo, setPhoto] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => onAuthStateChanged(auth, setUser), []);
  useEffect(() => {
    if (!user) { setReports([]); return; }
    const q = query(collection(db, "reports"), where("userId", "==", user.uid), orderBy("createdAt", "desc"));
    return onSnapshot(q, snap => setReports(snap.docs.map(d => ({ id: d.id, ...d.data() }))),
      e => setError("Could not load reports. Check Firestore setup and security rules. " + e.message));
  }, [user]);

  const visibleReports = useMemo(() => filter === "all" ? reports : reports.filter(r => (r.status || "submitted") === filter), [reports, filter]);

  function useCurrentLocation() {
    setError(""); setNotice("");
    if (!navigator.geolocation) { setError("Your browser does not support location. Click the map to place a pin."); return; }
    navigator.geolocation.getCurrentPosition(
      p => { setPosition({ lat: p.coords.latitude, lng: p.coords.longitude }); setNotice("Location selected. Check the pin on the map."); },
      () => setError("Location access was denied or unavailable. You can still click the map to place a pin."),
      { enableHighAccuracy: true, timeout: 12000 }
    );
  }

  async function submitReport(event) {
    event.preventDefault(); setError(""); setNotice("");
    if (!position) { setError("Choose the location by clicking the map or using your current location."); return; }
    if (photo && photo.size > 5 * 1024 * 1024) { setError("Please choose a photo smaller than 5 MB."); return; }
    setBusy(true);
    try {
      let photoURL = "";
      if (photo) {
        const safeName = photo.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-100);
        const imageRef = ref(storage, `report-photos/${user.uid}/${Date.now()}-${safeName}`);
        await uploadBytes(imageRef, photo, { contentType: photo.type });
        photoURL = await getDownloadURL(imageRef);
      }
      const docRef = await addDoc(collection(db, "reports"), {
        userId: user.uid,
        reporterName: user.displayName || "",
        title: title.trim(),
        description: description.trim(),
        severity,
        latitude: position.lat,
        longitude: position.lng,
        photoURL,
        status: "submitted",
        createdAt: serverTimestamp()
      });
      setTitle(""); setDescription(""); setSeverity("moderate"); setPosition(null); setPhoto(null);
      event.target.reset();
      setView("my-reports");
      setNotice(`Report submitted successfully. Reference: ${docRef.id}`);
    } catch (e) {
      setError("Report could not be submitted. Confirm Firestore, Storage and their security rules are configured. " + e.message);
    } finally { setBusy(false); }
  }

  if (user === undefined) return <div className="loading-screen">Loading AeroPatch…</div>;
  if (!user) return <AuthPanel />;

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">A</span><span>AeroPatch</span></div>
      <p className="side-label">WORKSPACE</p>
      <button className={`nav-item ${view==="report"?"active":""}`} onClick={()=>{setView("report");setNotice("");}}><span>＋</span> Report a pothole</button>
      <button className={`nav-item ${view==="my-reports"?"active":""}`} onClick={()=>{setView("my-reports");setNotice("");}}><span>▤</span> My reports <b>{reports.length}</b></button>
      <div className="sidebar-bottom">
        <div className="avatar">{(user.displayName || user.email || "U").slice(0,1).toUpperCase()}</div>
        <div className="user-meta"><strong>{user.displayName || "AeroPatch user"}</strong><small>{user.email}</small></div>
        <button className="signout" title="Sign out" onClick={()=>signOut(auth)}>↪</button>
      </div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div><span className="eyebrow">ROAD SAFETY, TOGETHER</span><h1>{view==="report"?"Report a pothole":"My reports"}</h1></div><div className="user-pill"><span className="online-dot"></span> Signed in</div></header>
      <section className="intro-row">
        <div><h2>{view==="report"?"See a pothole? Mark the spot.":"Your community reports"}</h2><p>{view==="report"?"Add the details and pin the exact location so the issue can be reviewed.":"Follow the latest status of reports submitted from your account."}</p></div>
        <div className="stat-chip"><span className="stat-number">{reports.length}</span><span>Total reports</span></div>
      </section>
      {notice && <div className="success" role="status">{notice}</div>}
      {error && <div className="error global-error" role="alert">{error}</div>}

      {view==="report" ? <div className="report-grid">
        <form className="panel report-form" onSubmit={submitReport}>
          <div className="panel-heading"><span className="step-number">01</span><div><h3>Issue details</h3><p>Describe what you noticed.</p></div></div>
          <label>Report title<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Deep pothole near bus stop" maxLength={100} required /></label>
          <label>Description<textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Nearby landmark, road condition, or other useful details…" rows={4} maxLength={1200} required /></label>
          <label>Severity<select value={severity} onChange={e=>setSeverity(e.target.value)}><option value="low">Low — small surface damage</option><option value="moderate">Moderate — may affect vehicles</option><option value="high">High — significant road hazard</option></select></label>
          <div className="panel-heading location-heading"><span className="step-number">02</span><div><h3>Pin the location</h3><p>Click the map or use your device location.</p></div></div>
          <div className="location-actions"><button type="button" className="secondary" onClick={useCurrentLocation}>◎ Use my location</button><span className="muted tiny">{position ? `${position.lat.toFixed(5)}, ${position.lng.toFixed(5)}` : "No location selected"}</span></div>
          <LocationMap position={position} onPick={p=>{setPosition(p);setNotice("");setError("");}} />
          <p className="map-hint">Tip: click directly on the pothole's position on the map to place or move the pin. Map data © OpenStreetMap contributors.</p>
          <label className="upload-label">Photo (optional, max 5 MB)<input type="file" accept="image/*" onChange={e=>setPhoto(e.target.files?.[0] || null)} /><span className="file-help">{photo ? photo.name : "Choose a photo from your device"}</span></label>
          <div className="privacy-note"><span>🔒</span><p>Your report is linked to your account. Avoid including faces, vehicle number plates, or other people's personal information in photos.</p></div>
          <button className="primary full" disabled={busy}>{busy ? "Submitting report…" : "Submit pothole report →"}</button>
        </form>
        <aside className="right-column">
          <div className="panel guide-panel"><span className="guide-icon">✦</span><h3>What happens next?</h3><div className="timeline"><div><span className="timeline-dot"></span><strong>Report received</strong><p>Your report is saved with its location.</p></div><div><span className="timeline-dot"></span><strong>Review</strong><p>A reviewer can check the details and update the status.</p></div><div><span className="timeline-dot"></span><strong>Repair update</strong><p>Progress can be recorded after a repair team confirms it.</p></div></div></div>
          <div className="panel safety-panel"><h3>Help keep reports useful</h3><ul><li>Pin the pothole, not your home.</li><li>Use a clear photo taken from a safe place.</li><li>Never stand in traffic to take a photo.</li></ul></div>
          <div className="mini-map-card"><div className="mini-map-art"><span className="mini-pin">●</span><span className="mini-road"></span><span className="mini-pin second">●</span></div><div><strong>Location matters</strong><p>Accurate pins help reviewers find the road issue.</p></div></div>
        </aside>
      </div> : <section className="panel reports-panel">
        <div className="reports-toolbar"><div><h3>Submitted reports</h3><p className="muted">Only reports submitted by your account appear here.</p></div><select value={filter} onChange={e=>setFilter(e.target.value)} aria-label="Filter reports"><option value="all">All statuses</option><option value="submitted">Reported</option><option value="reviewing">Under review</option><option value="repairing">Repair in progress</option><option value="resolved">Resolved</option></select></div>
        {visibleReports.length===0 ? <div className="empty-state"><span>⌁</span><h3>No reports yet</h3><p>When you submit a pothole report, it will appear here.</p><button className="primary" onClick={()=>setView("report")}>Create your first report</button></div> :
          <div className="report-list">{visibleReports.map(r=><article className="report-item" key={r.id}>
            {r.photoURL ? <img className="report-thumb" src={r.photoURL} alt="Pothole submitted with report" /> : <div className="report-thumb placeholder-thumb">⌁</div>}
            <div className="report-detail"><div className="report-title-row"><h4>{r.title}</h4><span className={`status status-${r.status || "submitted"}`}>{statusLabels[r.status || "submitted"] || "Reported"}</span></div>
              <p>{r.description}</p><div className="report-meta"><span>Severity: {r.severity}</span><span>📍 {Number(r.latitude).toFixed(5)}, {Number(r.longitude).toFixed(5)}</span></div>
              <a className="map-link" href={`https://www.openstreetmap.org/?mlat=${r.latitude}&mlon=${r.longitude}#map=18/${r.latitude}/${r.longitude}`} target="_blank" rel="noreferrer">Open location ↗</a>
            </div>
          </article>)}</div>}
      </section>}
      <footer className="footer">AeroPatch · Community road reporting <span>Built for safer streets</span></footer>
    </main>
  </div>;
}

export default App;
